/*
    Taylor J. Brown
    01MAR22
    GPACalculator
    -This program takes in the grades and credit value for each class taken 
        and gives the user a current running GPA calculation.
*/

package gpacalculator;

import java.util.*;

public class GPACalculator {
    public static Scanner KB = new Scanner(System.in);
    public static List<Double> GPAs = new ArrayList<>();
    public static List<Double> CREDITS = new ArrayList<>();

    public static void main(String[] args) {
        boolean exit = false;
        while (exit == false) {
            System.out.println("Menu:");
            System.out.println("1. Enter previous semesters GPA's");
            System.out.println("2. Calculate current semesters GPA");
            System.out.println("3. Calculate running GPA for all semesters");
            System.out.println("4. Display all GPA's and credits for each semester");
            System.out.println("5. Clear all entered GPA's");
            System.out.println("6. Exit");
            System.out.print("\nEnter choice: ");

            switch (KB.next()) {
                case "1":
                    prev_Semesters();
                    continue;
                case "2":
                    calc_Current();
                    continue;
                case "3":
                    running_avg();
                    continue;
                case "4":
                    if (!GPAs.isEmpty()) {
                        for (int i = 0; i < GPAs.size(); i++) {
                            System.out.print("\n" + (i + 1));
                            System.out.printf(". GPA: %.2f", GPAs.get(i));
                            System.out.print(" Credits: " + CREDITS.get(i));
                        }
                        System.out.println("\n");
                    } else {
                        System.out.println("\nNothing to show.\n");
                    }
                    continue;
                case "5":
                    if (!GPAs.isEmpty()) {
                        GPAs.clear();
                        CREDITS.clear();
                        System.out.println("\nAll GPA's cleared.\n");
                    } else {
                        System.out.println("\nNothing to clear.\n");
                    }
                    continue;
                case "6":
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid Option!\n");
            }
        }
    }

    public static void prev_Semesters() {
        int semesters_Taken = 0;
        int i;
        double CREDIT;
        boolean exit = false;

        while (!exit) {
            try {
                // Takes in the users amount of classes taken
                System.out.print("\nHow many semesters have you taken?: ");
                semesters_Taken = KB.nextInt();
            } catch (Exception e) {
                System.out.println("\nError incountered: Please enter a valid entry!\n");
            }
            for (i = 0; i < semesters_Taken; i++) {
                boolean valid = false;
                while (!valid) {
                    try {
                        System.out.print(i + 1 + ". GPA for semester: ");
                        double GPA = KB.nextDouble();
                        if (GPA >= 0.0) {
                            GPAs.add(GPA);
                            break;
                        } else {
                            System.out.println("Error incountered: Please enter a valid GPA!");
                        }
                    }

                    catch (Exception e) {
                        System.out.println("Error incountered: Please enter a valid GPA!");
                        KB.next();

                    }
                }

                while (!valid) {
                    try {
                        System.out.print("   Total credits in semester: ");
                        CREDIT = KB.nextDouble();
                        if (CREDIT > 0) {
                            CREDITS.add(CREDIT);
                            break;
                        } else {
                            System.out.println("   Error incountered: Please enter a valid credit value!");
                        }
                    } catch (Exception e) {
                        System.out.println("   Error incountered: Please enter a valid credit value!");
                        KB.next();
                    }
                }
            }

            System.out.println();
            exit = true;
        }
    }

    public static void calc_Current() {
        boolean exit = false;
        do {
            try {
                // Takes in the users amount of classes taken
                System.out.print("\nHow many classes did you take this last semester?: ");

                int classes_Taken;
                try {
                    classes_Taken = KB.nextInt();
                } catch (Exception e) {
                    System.out.println("Error incountered: Please enter a valid entry!");
                    KB.next();
                    continue;
                }

                // Method to get user information and calculate the GPA
                double GPA = Get_User_Grades(classes_Taken);
                System.out.printf("\nYour GPA for this semester: %.2f\n\n", GPA);
                exit = true;
            } catch (Exception e) {
                System.out.println("\nError incountered: Please enter a valid entry!\n");
            }
        } while (!exit);
    }

    public static void running_avg() {
        if (GPAs.isEmpty()) {
            System.out.println("\nPlease enter at least one GPA first!\n");
        } else {
            int count = GPAs.size();
            double total_GPA_Points = 0.0;
            double total_Credits = 0;

            for (int i = 0; i < count; i++) {
                total_GPA_Points += GPAs.get(i) * CREDITS.get(i);
                total_Credits += CREDITS.get(i);
            }

            double running_average = total_GPA_Points / total_Credits;
            System.out.printf("\nYour running average is: %.2f\n\n", running_average);
        }
    }

    public static double Get_User_Grades(int count) {
        // Declaring new lists to hold users inputed class data
        List<String> grades = new ArrayList<>();
        List<Double> grade_Points = new ArrayList<>();
        List<Double> credits = new ArrayList<>();

        // Gets the grade and credit worth from the user and adds them to
        // to the correct lists
        for (int i = 0; i < count; i++) {
            boolean valid = false;
            System.out.println();
            // Collects the grade for the class
            while (!valid) {
                System.out.print("What was the grade achieved?: ");
                String grade = KB.next();
                grade = grade.toLowerCase();

                if (grade.equals("a") || grade.equals("b") || grade.equals("c") || grade.equals("d")
                        || grade.equals("f")) {
                    grades.add(grade);
                    break;
                }
                System.out.println("That is not a valid grade");
            }

            // Collects the credit value for the class
            while (!valid) {
                double credit = 0.0;
                System.out.print("How many credits did that class have?: ");
                try {
                    credit = KB.nextInt();
                } catch (Exception e) {
                    KB.next();
                }

                if (credit > 0 && credit < 6) {
                    credits.add(credit);
                    break;
                }
                System.out.println("That is not a valid credit amount");
            }
        }

        // Assigns a grade point to a list based of the letter inputted
        for (int i = 0; i < count; i++) {
            String grade = grades.get(i);
            switch (grade) {
                case "a":
                    grade_Points.add(4.0);
                    continue;
                case "b":
                    grade_Points.add(3.0);
                    continue;
                case "c":
                    grade_Points.add(2.0);
                    continue;
                case "d":
                    grade_Points.add(1.0);
                    continue;
                default:
                    grade_Points.add(0.0);
            }
        }

        // Generates the total of all grades multiplied by there credit worth
        // and adds all the credits together
        double total = 0.0;
        double total_credits = 0.0;
        for (int i = 0; i < count; i++) {
            total += grade_Points.get(i) * credits.get(i);
            total_credits += credits.get(i);
        }

        // Calculates the GPA and returns it back to main
        double GPA = total / total_credits;
        GPAs.add(GPA);
        CREDITS.add(total_credits);

        return GPA;
    }
}
