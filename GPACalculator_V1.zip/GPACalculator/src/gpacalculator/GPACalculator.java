/*
    Taylor J. Brown
    01MAR22
    GPACalculator
    -This program takes in the grades and credit value for each class taken 
        and gives the user a current running GPA calculation.
*/

package gpacalculator;
import java.util.Scanner;
import java.util.*;

public class GPACalculator {
    public static Scanner KB = new Scanner(System.in);
    public static List<Double> GPAs = new ArrayList<>();
    public static List<Integer> CREDITS = new ArrayList<>();
    
    public static void main(String[] args) {
        boolean exit = false;
        while (exit == false)
        {
            System.out.println("Menu:");
            System.out.println("1. Enter previous semesters GPA's");
            System.out.println("2. Calculate current semesters GPA");
            System.out.println("3. Calculate running GPA for all semesters");
            System.out.println("4. Display all GPA's and credits for each semester");
            System.out.println("5. Clear all entered GPA's");
            System.out.println("6. Exit");
            System.out.print("\nEnter choice: ");
                
            String user_inp = KB.next();
            
            switch (user_inp){
                case "1":
                    prev_Semesters();
                    continue;
                case "2":
                    calc_Current();
                    continue;
                case "3":
                    running_avg();
                    continue;
                case "4":
                    if (!GPAs.isEmpty()){
                        for (int i = 0; i < GPAs.size(); i++){
                            System.out.print("\n" + (i+1) + ". GPA:" + GPAs.get(i) + " Credits:" + CREDITS.get(i));
                        }
                        System.out.println("\n"); 
                    }else{
                        System.out.println("\nNothing to show.\n");
                    }
                    continue;
                case "5":
                    if (!GPAs.isEmpty()){
                        GPAs.clear();
                        CREDITS.clear();
                        System.out.println("\nAll GPA's cleared.\n"); 
                    }else{
                        System.out.println("\nNothing to clear.\n");
                    }
                    continue;
                case "6":
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid Option!\n");
            }
        }
    }
    
    
    public static void prev_Semesters(){
        boolean exit = false;
        do{
            try
            {
                // Takes in the users amount of classes taken
                System.out.print("\nHow many semesters have you taken?: ");
                String user_inp = KB.next();
                int semesters_Taken = Integer.parseInt(user_inp);

                for (int i = 0; i < semesters_Taken; i++){
                    System.out.print(i+1 + ". GPA for semester: ");
                    GPAs.add(KB.nextDouble());
                    
                    System.out.print("   Total credits in semester: ");
                    CREDITS.add(KB.nextInt());
                }
                System.out.println();
                
                exit = true;
            }
            catch(NumberFormatException e)
            {
                System.out.println("\nError incountered: Please enter a valid entry!\n");
            } 
        }while(!exit);
    }
    
    
    public static void calc_Current(){
        double GPA = 0;
        
        boolean exit = false;
        do{
            try
            {
                // Takes in the users amount of classes taken
                System.out.print("How many classes did you take this last semester?: ");
                String user_inp = KB.next();
                int classes_Taken = Integer.parseInt(user_inp);

                // Method to get user information and calculate the GPA
                GPA = Get_User_Grades(classes_Taken,GPA);
                System.out.println("\nYour GPA for this semester: " + GPA); 
                exit = true;
            }
            catch(NumberFormatException e)
            {
                System.out.println("\nError incountered: Please enter a valid entry!\n");
            } 
        }while(!exit);
    }
    
    
    public static void running_avg(){
        if (GPAs.isEmpty()){
            System.out.println("\nPlease enter at least one GPA first!\n");
        }else{
            int count = GPAs.size();
            double total_GPA_Points = 0.0;
            int total_Credits = 0;
            
            for (int i = 0; i < count; i++){
                total_GPA_Points += GPAs.get(i) * CREDITS.get(i);
                total_Credits += CREDITS.get(i);
            }
            
            double running_average = total_GPA_Points / total_Credits;
            System.out.println("\nYour running average is: " + running_average + "\n");
        }
    }
    
    
    public static double Get_User_Grades(int count, double GPA){
        //Declaring new lists to hold users inputed class data
        List<String> grades = new ArrayList<>();
        List<Double> grade_Points = new ArrayList<>();
        List<Integer> credits = new ArrayList<>();
        
        // Gets the grade and credit worth from the user and adds them to 
        // to the correct lists
        for (int i= 0; i < count; i++){
            System.out.print("What was the grade achieved?: ");
            grades.add(KB.next());
            
            System.out.print("How many credits did that class have?: ");
            credits.add(KB.nextInt());
        }
        
        // Assigns a grade point to a list based of the letter inputted
        for (int i = 0; i < count; i++){
            String grade = grades.get(i);
            switch(grade){
                case "A":
                case "a":
                    grade_Points.add(4.0);
                    continue;
                case "B":
                case "b":
                    grade_Points.add(3.0);
                    continue;
                case "C":
                case "c":
                   grade_Points.add(2.0);
                   continue;
                case "D":
                case "d":
                    grade_Points.add(1.0);
                    continue;
                default:
                    grade_Points.add(0.0);
            }
        }
        
        // Generates the total of all grades multiplied by there credit worth 
        // and adds all the credits together 
        double total = 0.0;
        int total_credits = 0;
        for (int i = 0; i < count; i++){
            total += grade_Points.get(i)* credits.get(i);
            total_credits += credits.get(i);
        }
        
        // Calculates the GPA and returns it back to main
        GPA = total / total_credits;
        GPAs.add(GPA);
        CREDITS.add(total_credits);
        
        return GPA;
    } 
}
